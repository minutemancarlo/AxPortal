<!-- sidebar navigation component -->
<nav id="sidebar" class="active">
    <div class="sidebar-header">
      <img src="../assets/img/<?php echo $brlogo; ?>" style="height: 30px;" alt="logo" class="app-logo">
    </div>
    <ul class="list-unstyled components text-secondary">
        <?php echo $menuTags; ?>
    </ul>
</nav>
<!-- end of sidebar component -->
